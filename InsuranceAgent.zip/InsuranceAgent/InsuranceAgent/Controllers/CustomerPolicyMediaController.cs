﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InsuranceAgent.Models;
using System.IO;

namespace InsuranceAgent.Controllers
{
    [Authorize]
    public class CustomerPolicyMediaController : Controller
    {
        private InsuranceAgentEntities db = new InsuranceAgentEntities();

        //
        // GET: /CustomerPolicyMedia/

        public ActionResult Index(int id = 0)
        {
            if (id == 0)
            {
                var customerpolicymedias = db.CustomerPolicyMedias.Include(c => c.CustomerPolicy);
                return View(customerpolicymedias.ToList());
            }
            else
            {
                var customerpolicymedias = db.CustomerPolicyMedias.Where(m=>m.CustomerPolicyID==id).Include(c => c.CustomerPolicy);
                return View(customerpolicymedias.ToList());
            }
        }

        //
        // GET: /CustomerPolicyMedia/Details/5

        public ActionResult Details(int id = 0)
        {
            CustomerPolicyMedia customerpolicymedia = db.CustomerPolicyMedias.Find(id);
            if (customerpolicymedia == null)
            {
                return HttpNotFound();
            }
            return View(customerpolicymedia);
        }

        //
        // GET: /CustomerPolicyMedia/Create

        public ActionResult Create(int id = 0)
        {
            ViewBag.CustomerPolicyID = new SelectList(db.CustomerPolicies, "CustomerPolicyID", "PolicyNumber",id);
            return View();
        }

        //
        // POST: /CustomerPolicyMedia/Create

        [HttpPost]
        public ActionResult Create(CustomerPolicyMediaFile customerpolicymediafile)
        {
            customerpolicymediafile.CreatedDate = Common.GetCurrentDate();
            customerpolicymediafile.UpdatedDate = customerpolicymediafile.CreatedDate;
            customerpolicymediafile.UpdatedByID = WebMatrix.WebData.WebSecurity.GetUserId(User.Identity.Name);
            if (ModelState.IsValid)
            {
                CustomerPolicyMedia customerpolicymedia = new CustomerPolicyMedia();
                customerpolicymedia.CustomerPolicyID = customerpolicymediafile.CustomerPolicyID;
                customerpolicymedia.FileName = System.IO.Path.GetFileName(customerpolicymediafile.File.FileName);
                customerpolicymedia.CreatedDate = customerpolicymediafile.CreatedDate;
                customerpolicymedia.UpdatedDate = customerpolicymediafile.UpdatedDate;
                customerpolicymedia.UpdatedByID = customerpolicymediafile.UpdatedByID;
                customerpolicymedia.MediaType = customerpolicymediafile.File.ContentType;
                customerpolicymedia.MediaTitle = customerpolicymediafile.MediaTitle;
                byte[] uploadedFile = new byte[customerpolicymediafile.File.InputStream.Length];
                customerpolicymediafile.File.InputStream.Read(uploadedFile, 0, uploadedFile.Length);
                customerpolicymedia.FileData = uploadedFile;
                db.CustomerPolicyMedias.Add(customerpolicymedia);
                db.SaveChanges();
                return RedirectToAction("Details", "CustomerPolicy", new { id = customerpolicymedia.CustomerPolicyID });
            }

            ViewBag.CustomerPolicyID = new SelectList(db.CustomerPolicies, "CustomerPolicyID", "PolicyNumber", customerpolicymediafile.CustomerPolicyID);
            return View(customerpolicymediafile);
        }

        public ActionResult GetFile(int id = 0)
        {
            CustomerPolicyMedia customerpolicymedia = db.CustomerPolicyMedias.Find(id);
            if (customerpolicymedia == null)
            {
                return HttpNotFound();
            }
            MemoryStream ms = new MemoryStream(customerpolicymedia.FileData, 0, 0, true, true);
            Response.ContentType = customerpolicymedia.MediaType;
            Response.AddHeader("content-disposition", "attachment;filename=" + customerpolicymedia.FileName);
            Response.Buffer = true;
            Response.Clear();
            Response.OutputStream.Write(ms.GetBuffer(), 0, ms.GetBuffer().Length);
            Response.OutputStream.Flush();
            Response.End();
            return new FileStreamResult(Response.OutputStream, customerpolicymedia.MediaType);
        }

        //
        // GET: /CustomerPolicyMedia/Edit/5

        public ActionResult Edit(int id = 0)
        {
            CustomerPolicyMedia customerpolicymedia = db.CustomerPolicyMedias.Find(id);
            if (customerpolicymedia == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerPolicyID = new SelectList(db.CustomerPolicies, "CustomerPolicyID", "PolicyNumber", customerpolicymedia.CustomerPolicyID);
            return View(customerpolicymedia);
        }

        //
        // POST: /CustomerPolicyMedia/Edit/5

        [HttpPost]
        public ActionResult Edit(CustomerPolicyMedia customerpolicymedia)
        {
            customerpolicymedia.UpdatedDate = Common.GetCurrentDate();
            customerpolicymedia.UpdatedByID = WebMatrix.WebData.WebSecurity.GetUserId(User.Identity.Name);
            if (ModelState.IsValid)
            {
                CustomerPolicyMedia media = db.CustomerPolicyMedias.Find(customerpolicymedia.MediaID);
                if (media != null)
                {
                    media.UpdatedDate = customerpolicymedia.UpdatedDate;
                    media.UpdatedByID = customerpolicymedia.UpdatedByID;
                    media.FileName = customerpolicymedia.FileName;
                    media.MediaTitle = customerpolicymedia.MediaTitle;
                    db.Entry(media).State = EntityState.Modified;
                    db.SaveChanges();
                }
                return RedirectToAction("Details", "CustomerPolicy", new { id = customerpolicymedia.CustomerPolicyID });
            }
            ViewBag.CustomerPolicyID = new SelectList(db.CustomerPolicies, "CustomerPolicyID", "PolicyNumber", customerpolicymedia.CustomerPolicyID);
            return View(customerpolicymedia);
        }

        //
        // GET: /CustomerPolicyMedia/Delete/5

        public ActionResult Delete(int id = 0)
        {
            CustomerPolicyMedia customerpolicymedia = db.CustomerPolicyMedias.Find(id);
            if (customerpolicymedia == null)
            {
                return HttpNotFound();
            }
            return View(customerpolicymedia);
        }

        //
        // POST: /CustomerPolicyMedia/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            CustomerPolicyMedia customerpolicymedia = db.CustomerPolicyMedias.Find(id);
            db.CustomerPolicyMedias.Remove(customerpolicymedia);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}