﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InsuranceAgent.Models;

namespace InsuranceAgent.Controllers
{
    [Authorize]
    public class PolicyMasterController : Controller
    {
        private InsuranceAgentEntities db = new InsuranceAgentEntities();

        //
        // GET: /PolicyMaster/

        public ActionResult Index()
        {
            var policymasters = db.PolicyMasters.Include(p => p.PolicyCompany).Include(p => p.PolicyType);
            return View(policymasters.ToList());
        }

        //
        // GET: /PolicyMaster/Details/5

        public ActionResult Details(int id = 0)
        {
            PolicyMaster policymaster = db.PolicyMasters.Find(id);
            if (policymaster == null)
            {
                return HttpNotFound();
            }
            return View(policymaster);
        }

        //
        // GET: /PolicyMaster/Create

        public ActionResult Create()
        {
            ViewBag.CompanyID = new SelectList(db.PolicyCompanies, "CompanyID", "Company");
            ViewBag.PolicyTypeID = new SelectList(db.PolicyTypes, "PolicyTypeID", "PolicyTypeName");
            return View();
        }

        //
        // POST: /PolicyMaster/Create

        [HttpPost]
        public ActionResult Create(PolicyMaster policymaster)
        {
            policymaster.CreatedDate = Common.GetCurrentDate();
            policymaster.UpdatedDate = policymaster.CreatedDate;
            policymaster.UpdatedByID = WebMatrix.WebData.WebSecurity.GetUserId(User.Identity.Name);
            if (ModelState.IsValid)
            {
                db.PolicyMasters.Add(policymaster);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CompanyID = new SelectList(db.PolicyCompanies, "CompanyID", "Company", policymaster.CompanyID);
            ViewBag.PolicyTypeID = new SelectList(db.PolicyTypes, "PolicyTypeID", "PolicyTypeName", policymaster.PolicyTypeID);
            return View(policymaster);
        }

        //
        // GET: /PolicyMaster/Edit/5

        public ActionResult Edit(int id = 0)
        {
            PolicyMaster policymaster = db.PolicyMasters.Find(id);
            if (policymaster == null)
            {
                return HttpNotFound();
            }
            ViewBag.CompanyID = new SelectList(db.PolicyCompanies, "CompanyID", "Company", policymaster.CompanyID);
            ViewBag.PolicyTypeID = new SelectList(db.PolicyTypes, "PolicyTypeID", "PolicyTypeName", policymaster.PolicyTypeID);
            return View(policymaster);
        }

        //
        // POST: /PolicyMaster/Edit/5

        [HttpPost]
        public ActionResult Edit(PolicyMaster policymaster)
        {
            policymaster.UpdatedDate = Common.GetCurrentDate();
            policymaster.UpdatedByID = WebMatrix.WebData.WebSecurity.GetUserId(User.Identity.Name);
            if (ModelState.IsValid)
            {
                db.Entry(policymaster).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CompanyID = new SelectList(db.PolicyCompanies, "CompanyID", "Company", policymaster.CompanyID);
            ViewBag.PolicyTypeID = new SelectList(db.PolicyTypes, "PolicyTypeID", "PolicyTypeName", policymaster.PolicyTypeID);
            return View(policymaster);
        }

        //
        // GET: /PolicyMaster/Delete/5

        public ActionResult Delete(int id = 0)
        {
            PolicyMaster policymaster = db.PolicyMasters.Find(id);
            if (policymaster == null)
            {
                return HttpNotFound();
            }
            return View(policymaster);
        }

        //
        // POST: /PolicyMaster/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            PolicyMaster policymaster = db.PolicyMasters.Find(id);
            db.PolicyMasters.Remove(policymaster);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}