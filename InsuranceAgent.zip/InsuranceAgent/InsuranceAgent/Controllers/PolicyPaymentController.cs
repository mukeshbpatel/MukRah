﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InsuranceAgent.Models;

namespace InsuranceAgent.Controllers
{
    [Authorize]
    public class PolicyPaymentController : Controller
    {
        private InsuranceAgentEntities db = new InsuranceAgentEntities();

        //
        // GET: /PolicyPayment/

        public ActionResult Index(int CustomerPolicyID = 0)
        {
            if (CustomerPolicyID == 0)
            {
                var policypayments = db.PolicyPayments.Include(p => p.CustomerPolicy).Include(t => t.PaymentStatus);
                return View(policypayments.ToList());
            }
            else
            {
                var policypayments = db.PolicyPayments.Where(p => p.CustomerPolicyID == CustomerPolicyID).Include(p => p.CustomerPolicy).Include(t => t.PaymentStatus);
                return View(policypayments.ToList());
            }
        }

        //
        // GET: /PolicyPayment/Details/5

        public ActionResult Details(int id = 0)
        {
            PolicyPayment policypayment = db.PolicyPayments.Find(id);
            if (policypayment == null)
            {
                return HttpNotFound();
            }
            return View(policypayment);
        }

        //
        // GET: /PolicyPayment/Create

        public ActionResult Create()
        {
            ViewBag.CustomerPolicyID = new SelectList(db.CustomerPolicies, "CustomerPolicyID", "PolicyNumber");
            ViewBag.PaymentStatusID = new SelectList(Common.GetKeyValues(db.KeyValues, "PaymentStatus"), "KeyID", "KeyValues");            
            return View();
        }

        //
        // POST: /PolicyPayment/Create

        [HttpPost]
        public ActionResult Create(PolicyPayment policypayment)
        {
            policypayment.CreatedDate = Common.GetCurrentDate();
            policypayment.UpdatedDate = policypayment.CreatedDate;
            policypayment.UpdatedByID = WebMatrix.WebData.WebSecurity.GetUserId(User.Identity.Name);
            if (ModelState.IsValid)
            {
                try
                {
                    db.PolicyPayments.Add(policypayment);
                    db.SaveChanges();
                    return RedirectToAction("Details", "CustomerPolicy", new { id = policypayment.CustomerPolicyID });
                }
                catch (Exception ex)
                {
                   string m = ex.Message;
                }                
            }

            ViewBag.CustomerPolicyID = new SelectList(db.CustomerPolicies, "CustomerPolicyID", "PolicyNumber", policypayment.CustomerPolicyID);
            ViewBag.PaymentStatusID = new SelectList(Common.GetKeyValues(db.KeyValues, "PaymentStatus"), "KeyID", "KeyValues", policypayment.PaymentStatusID);
            return View(policypayment);
        }

        //
        // GET: /PolicyPayment/Edit/5

        public ActionResult Edit(int id = 0)
        {
            PolicyPayment policypayment = db.PolicyPayments.Find(id);
            if (policypayment == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerPolicyID = new SelectList(db.CustomerPolicies, "CustomerPolicyID", "PolicyNumber", policypayment.CustomerPolicyID);
            ViewBag.PaymentStatusID = new SelectList(Common.GetKeyValues(db.KeyValues, "PaymentStatus"), "KeyID", "KeyValues", policypayment.PaymentStatusID);
            return View(policypayment);
        }

        //
        // POST: /PolicyPayment/Edit/5

        [HttpPost]
        public ActionResult Edit(PolicyPayment policypayment)
        {
            policypayment.UpdatedDate = Common.GetCurrentDate();
            policypayment.UpdatedByID = WebMatrix.WebData.WebSecurity.GetUserId(User.Identity.Name);
            if (ModelState.IsValid)
            {
                db.Entry(policypayment).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Details", "CustomerPolicy", new { id = policypayment.CustomerPolicyID });
            }
            ViewBag.CustomerPolicyID = new SelectList(db.CustomerPolicies, "CustomerPolicyID", "PolicyNumber", policypayment.CustomerPolicyID);
            ViewBag.PaymentStatusID = new SelectList(Common.GetKeyValues(db.KeyValues,"PaymentStatus"), "KeyID", "KeyValues", policypayment.PaymentStatusID);
            return View(policypayment);
        }

        //
        // GET: /PolicyPayment/Delete/5

        public ActionResult Delete(int id = 0)
        {
            PolicyPayment policypayment = db.PolicyPayments.Find(id);
            if (policypayment == null)
            {
                return HttpNotFound();
            }
            return View(policypayment);
        }

        //
        // POST: /PolicyPayment/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            PolicyPayment policypayment = db.PolicyPayments.Find(id);
            db.PolicyPayments.Remove(policypayment);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}