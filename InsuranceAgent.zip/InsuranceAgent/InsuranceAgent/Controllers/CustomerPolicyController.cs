﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InsuranceAgent.Models;

namespace InsuranceAgent.Controllers
{
    [Authorize]
    public class CustomerPolicyController : Controller
    {        
        private InsuranceAgentEntities db = new InsuranceAgentEntities();

        //
        // GET: /CustomerPolicy/

        public ActionResult Index(int CustomerID = 0)
        {
            if (CustomerID == 0)
            {
                var customerpolicies = db.CustomerPolicies.Include(c => c.Customer).Include(c => c.PolicyMaster);
                return View(customerpolicies.ToList());
            }
            else
            {
                var customerpolicies = db.CustomerPolicies.Where(p=>p.CustomerID == CustomerID).Include(c => c.Customer).Include(c => c.PolicyMaster);
                return View(customerpolicies.ToList());
            }
        }

        //
        // GET: /CustomerPolicy/Details/5

        public ActionResult Details(int id = 0)
        {
            CustomerPolicy customerpolicy = db.CustomerPolicies.Find(id);
            if (customerpolicy == null)
            {
                return HttpNotFound();
            }
            return View(customerpolicy);
        }

        //
        // GET: /CustomerPolicy/Create

        public ActionResult Create()
        {
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "FullName");
            ViewBag.PolicyID = new SelectList(db.PolicyMasters, "PolicyID", "PolicyName");
            ViewBag.PremiumFrequency = new SelectList(Common.GetPremiumFrequency());
            ViewBag.PolicyStatus = new SelectList(Common.GetPolicyStatus());
            return View();
        }

        //
        // POST: /CustomerPolicy/Create

        [HttpPost]
        public ActionResult Create(CustomerPolicy customerpolicy)
        {
            customerpolicy.CreatedDate = Common.GetCurrentDate();
            customerpolicy.UpdatedDate = customerpolicy.CreatedDate;
            customerpolicy.UpdateByID = WebMatrix.WebData.WebSecurity.GetUserId(User.Identity.Name);
            if (ModelState.IsValid)
            {
                db.CustomerPolicies.Add(customerpolicy);
                db.SaveChanges();
                return RedirectToAction("Details", "Customer", new { id = customerpolicy.CustomerID });
            }

            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "FullName", customerpolicy.CustomerID);
            ViewBag.PolicyID = new SelectList(db.PolicyMasters, "PolicyID", "PolicyName", customerpolicy.PolicyID);
            ViewBag.PremiumFrequency = new SelectList(Common.GetPremiumFrequency());
            ViewBag.PolicyStatus = new SelectList(Common.GetPolicyStatus());
            return View(customerpolicy);
        }

        //
        // GET: /CustomerPolicy/Edit/5

        public ActionResult Edit(int id = 0)
        {
            CustomerPolicy customerpolicy = db.CustomerPolicies.Find(id);
            if (customerpolicy == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "FullName", customerpolicy.CustomerID);
            ViewBag.PolicyID = new SelectList(db.PolicyMasters, "PolicyID", "PolicyName", customerpolicy.PolicyID);
            ViewBag.PremiumFrequency = new SelectList(Common.GetPremiumFrequency(), customerpolicy.PremiumFrequency);
            ViewBag.PolicyStatus = new SelectList(Common.GetPolicyStatus(), customerpolicy.PolicyStatus);
            return View(customerpolicy);
        }

        //
        // POST: /CustomerPolicy/Edit/5

        [HttpPost]
        public ActionResult Edit(CustomerPolicy customerpolicy)
        {            
            customerpolicy.UpdatedDate = Common.GetCurrentDate();
            customerpolicy.UpdateByID = WebMatrix.WebData.WebSecurity.GetUserId(User.Identity.Name);
            if (ModelState.IsValid)
            {
                try
                {
                    db.Entry(customerpolicy).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Details", "Customer", new { id = customerpolicy.CustomerID });
                }
                catch (Exception ex)
                {
                    string a = ex.Message;
                }
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "FullName", customerpolicy.CustomerID);
            ViewBag.PolicyID = new SelectList(db.PolicyMasters, "PolicyID", "PolicyName", customerpolicy.PolicyID);
            ViewBag.PremiumFrequency = new SelectList(Common.GetPremiumFrequency(),customerpolicy.PremiumFrequency);
            ViewBag.PolicyStatus = new SelectList(Common.GetPolicyStatus(),customerpolicy.PolicyStatus);
            return View(customerpolicy);
        }

        //
        // GET: /CustomerPolicy/Delete/5

        public ActionResult Delete(int id = 0)
        {
            CustomerPolicy customerpolicy = db.CustomerPolicies.Find(id);
            if (customerpolicy == null)
            {
                return HttpNotFound();
            }
            return View(customerpolicy);
        }

        //
        // POST: /CustomerPolicy/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            CustomerPolicy customerpolicy = db.CustomerPolicies.Find(id);
            db.CustomerPolicies.Remove(customerpolicy);
            db.SaveChanges();
            return RedirectToAction("Details", "Customer", new { id = customerpolicy.CustomerID });
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}