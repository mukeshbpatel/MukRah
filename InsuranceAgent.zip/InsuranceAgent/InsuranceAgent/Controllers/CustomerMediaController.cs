﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InsuranceAgent.Models;
using System.IO;

namespace InsuranceAgent.Controllers
{
    public class CustomerMediaController : Controller
    {
        private InsuranceAgentEntities db = new InsuranceAgentEntities();

        //
        // GET: /CustomerMedia/

        public ActionResult Index(int id=0)
        {
            if (id == 0)
            {
                var customermedias = db.CustomerMedias.Include(c => c.Customer);
                return View(customermedias.ToList());
            }
            else
            {
                var customermedias = db.CustomerMedias.Where(m=>m.CustomerID == id).Include(c => c.Customer);
                return View(customermedias.ToList());
            }
        }

        //
        // GET: /CustomerMedia/Details/5

        public ActionResult Details(int id = 0)
        {
            CustomerMedia customermedia = db.CustomerMedias.Find(id);
            if (customermedia == null)
            {
                return HttpNotFound();
            }
            return View(customermedia);
        }

        //
        // GET: /CustomerMedia/Create

        public ActionResult Create(int id = 0)
        {
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "FullName", id);
            return View();
        }

        //
        // POST: /CustomerMedia/Create

        [HttpPost]
        public ActionResult Create(CustomerMediaFile customermediaFile)
        {

            customermediaFile.CreatedDate = Common.GetCurrentDate();
            customermediaFile.UpdatedDate = customermediaFile.CreatedDate;
            customermediaFile.UpdatedByID = WebMatrix.WebData.WebSecurity.GetUserId(User.Identity.Name);
            if (ModelState.IsValid)
            {
               
                CustomerMedia customermedia = new CustomerMedia();            
                customermedia.CustomerID = customermediaFile.CustomerID;
                customermedia.FileName = System.IO.Path.GetFileName(customermediaFile.File.FileName);
                customermedia.CreatedDate = customermediaFile.CreatedDate;
                customermedia.UpdatedDate = customermediaFile.UpdatedDate;
                customermedia.UpdatedByID = customermediaFile.UpdatedByID;
                customermedia.MediaType = customermediaFile.File.ContentType;
                customermedia.MediaTitle = customermediaFile.MediaTitle;
                byte[] uploadedFile = new byte[customermediaFile.File.InputStream.Length];
                customermediaFile.File.InputStream.Read(uploadedFile, 0, uploadedFile.Length);
                customermedia.FileData = uploadedFile;
                db.CustomerMedias.Add(customermedia);
                db.SaveChanges();
                return RedirectToAction("Details", "Customer", new {id=customermedia.CustomerID});
            }

            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "FullName", customermediaFile.CustomerID);
            return View(customermediaFile);
        }

        public ActionResult GetFile(int id = 0)
        {
            CustomerMedia customermedia = db.CustomerMedias.Find(id);
            if (customermedia == null)
            {
                return HttpNotFound();
            }
            MemoryStream ms = new MemoryStream(customermedia.FileData, 0, 0, true, true);
            Response.ContentType = customermedia.MediaType;
            Response.AddHeader("content-disposition", "attachment;filename=" + customermedia.FileName);
            Response.Buffer = true;
            Response.Clear();
            Response.OutputStream.Write(ms.GetBuffer(), 0, ms.GetBuffer().Length);
            Response.OutputStream.Flush();
            Response.End();            
            return new FileStreamResult(Response.OutputStream,customermedia.MediaType);
        }

        //
        // GET: /CustomerMedia/Edit/5

        public ActionResult Edit(int id = 0)
        {
            CustomerMedia customermedia = db.CustomerMedias.Find(id);
            if (customermedia == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "FullName", customermedia.CustomerID);
            return View(customermedia);
        }

        //
        // POST: /CustomerMedia/Edit/5

        [HttpPost]
        public ActionResult Edit(CustomerMedia customermedia)
        {
            customermedia.UpdatedDate = Common.GetCurrentDate();
            customermedia.UpdatedByID = WebMatrix.WebData.WebSecurity.GetUserId(User.Identity.Name);
            if (ModelState.IsValid)
            {
                db.Entry(customermedia).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Details", "Customer", new { id = customermedia.CustomerID });
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "FullName", customermedia.CustomerID);
            return View(customermedia);
        }

        //
        // GET: /CustomerMedia/Delete/5

        public ActionResult Delete(int id = 0)
        {
            CustomerMedia customermedia = db.CustomerMedias.Find(id);
            if (customermedia == null)
            {
                return HttpNotFound();
            }
            return View(customermedia);
        }

        //
        // POST: /CustomerMedia/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {            
            CustomerMedia customermedia = db.CustomerMedias.Find(id);
            db.CustomerMedias.Remove(customermedia);
            db.SaveChanges();
            return RedirectToAction("Details", "Customer", new { id = customermedia.CustomerID });
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}