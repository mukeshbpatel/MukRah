﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using System.Data;

namespace InsuranceAgent.Models
{
    public partial class PolicyTypeMetadata
    {
        [Display(Name = "Policy Type")]
        [StringLength(100)]
        [Required]
        public string PolicyTypeName { get; set; }        
    }
    [MetadataType(typeof(PolicyTypeMetadata))]
    public partial class PolicyType
    {
    }


    public partial class PolicyCompanyMetadata
    {
        [Display(Name = "Insurance Company")]
        [StringLength(100)]
        [Required]
        public string Company { get; set; }
    }
    [MetadataType(typeof(PolicyCompanyMetadata))]
    public partial class PolicyCompany
    {
    }


    public partial class FamilyMetadata
    {
        [Display(Name = "Family Name")]
        [StringLength(100)]
        [Required]
        public string FamilyName { get; set; }
    }
    [MetadataType(typeof(FamilyMetadata))]
    public partial class Family
    {
    }

    public partial class CustomerMeta
    {     
        public int CustomerID { get; set; }
        [StringLength(100)]
        [Required]
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        [StringLength(100)]
        [Required]        
        public string LastName { get; set; }
        [Display(Name = "Family")]
        public Nullable<int> FamilyID { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public System.DateTime DOB { get; set; }
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        [MaxLength(200)]
        public string Email { get; set; }        
        public string Relation { get; set; }
        [Display(Name = "Relation")]
        public string RelationCustomerID { get; set; }      
    }

    [MetadataType(typeof(CustomerMeta))]
    public partial class Customer
    {
    }


    public partial class PolicyMasterMeta
    {
        [Display(Name = "Policy Name")]
        [Required]
        public string PolicyName { get; set; }
        public string Description { get; set; }
        [Display(Name = "Company")]
        [Required]
        public int CompanyID { get; set; }
        [Display(Name = "Policy Type")]
        [Required]
        public int PolicyTypeID { get; set; }        
    }

    [MetadataType(typeof(PolicyMasterMeta))]
    public partial class PolicyMaster
    {
    }

    public partial class CustomerPolicyMeta
    {
        [Display(Name = "Customer")]
        [Required]        
        public int CustomerID { get; set; }
        [Display(Name = "Policy")]
        [Required]
        public int PolicyID { get; set; }
        [Display(Name = "Policy#")]
        [Required]
        public string PolicyNumber { get; set; }

        [Display(Name = "Issue Date")]
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public System.DateTime IssueDate { get; set; }
        
        [Display(Name = "Exp. Date")]        
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public Nullable<System.DateTime> ExpireDate { get; set; }
        
        [Required]
        [Display(Name = "Premium Frequency")]        
        public string PremiumFrequency { get; set; }

        [Display(Name = "Vechile Registration#")]
        public string VechileRegistrationNumber { get; set; }
        
        [Range(0,999999999999)]
        [Display(Name = "Sum Insured")]
        public decimal SumInsuredAmount { get; set; }
        
        [Range(0, 999999999999)]
        [Display(Name = "OD Premium")]
        [Required]
        public decimal ODPremiumAmount { get; set; }
        
        [Range(0, 999999999999)]
        [Display(Name = "OD Premium")]
        [Required]
        public decimal NetPremiumAmount { get; set; }
        
        [Range(0, 999999999999)]
        [Display(Name = "TP Premium")]
        [Required]
        public decimal TPPremiumAmount { get; set; }
        
        [Range(0, 999999999999)]
        [Display(Name = "Service Tax")]
        [Required]
        public decimal ServiceTax { get; set; }
        
        [Range(0, 999999999999)]
        [Display(Name = "Total Premium")]
        [Required]
        public decimal TotalPremiumAmount { get; set; }
        
        [Required]
        [Display(Name = "Insured Name")]
        public string InsuredName { get; set; }
        
        [Required]
        [Display(Name = "Policy Status")]
        public string PolicyStatus { get; set; }
        
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Policy Submited Date")]
        public Nullable<System.DateTime> PolicySubmitedDate { get; set; }
        
        public string LastPolicyNumber { get; set; }
        
        public Nullable<bool> IsHardCopy { get; set; }
        public Nullable<bool> IsRenewedPolicyReceived { get; set; }
        public Nullable<bool> IsDelivered { get; set; }
        
        public string Description { get; set; }        
    }

    [MetadataType(typeof(CustomerPolicyMeta))]
    public partial class CustomerPolicy
    {
    }


    public partial class PolicyPaymentMeta
    {
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]        
        [Display(Name = "Date")]
        [Required]        
        public System.DateTime PaymentDate { get; set; }

        [Display(Name = "Status")]
        [Required]        
        public int PaymentStatusID { get; set; }

        [Display(Name = "Policy")]
        [Required]                
        public int CustomerPolicyID { get; set; }

        [Display(Name = "Amount")]
        [Required]
        [Range(0, 999999999999)]  
        public decimal PaymentAmount { get; set; }
        public string PaymentDetails { get; set; }

        [Display(Name = "Commission")]        
        [Range(0, 999999999999)]  
        public decimal CommissionAmount { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Commission Date")]        
        public Nullable<System.DateTime> CommissionDate { get; set; }

        [Display(Name = "Commission Details")]        
        public string CommissionDetails { get; set; }        
    }

    [MetadataType(typeof(PolicyPaymentMeta))]
    public partial class PolicyPayment
    {
    }

    public partial class CustomerMediaFile : CustomerMedia
    {
        [Required]
        public HttpPostedFileBase File { get; set; }
    }

    public partial class CustomerMediaFileMeta
    {
        [Required]
        public int CustomerID { get; set; }
        [Display(Name = "Type")]
        public string MediaType { get; set; }
        [Required]
        [Display(Name = "Title")]
        public string MediaTitle { get; set; }
        public string FileName { get; set; }
        [Display(Name = "File")]
        public byte[] FileData { get; set; }
    }

    [MetadataType(typeof(CustomerMediaFileMeta))]
    public partial class CustomerMediaFile
    {
    }

    public partial class CustomerPolicyMediaFile : CustomerPolicyMedia
    {
        [Required]
        public HttpPostedFileBase File { get; set; }
    }

    public partial class CustomerPolicyMediaFileMeta
    {
        [Required]
        public int CustomerPolicyID { get; set; }
        [Display(Name = "Type")]
        public string MediaType { get; set; }
        [Required]
        [Display(Name = "Title")]
        public string MediaTitle { get; set; }
        public string FileName { get; set; }
        [Display(Name = "File")]
        public byte[] FileData { get; set; }
    }

    [MetadataType(typeof(CustomerPolicyMediaFileMeta))]
    public partial class CustomerPolicyMediaFile
    {
    }
}